# series-namer
I needed a tool to rename the files I get off of MakeMKV for shows to so that they match jellyfin conventions.
